package com.amir.spatialos

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

class SpatialRenderer : GLSurfaceView.Renderer {
    @Volatile var environment = 0
    @Volatile var panelMode = 0
    @Volatile var selectionPulse = 0f
    @Volatile private var headYaw = 0f
    @Volatile private var headPitch = 0f
    @Volatile private var headRoll = 0f
    fun setHeadOrientation(yaw: Float, pitch: Float, roll: Float) { headYaw = yaw; headPitch = pitch; headRoll = roll }
    private var program = 0
    private var positionHandle = 0
    private var colorHandle = 0
    private var mvpHandle = 0
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private var width = 1
    private var height = 1
    private val vertexBuffer: FloatBuffer = ByteBuffer.allocateDirect(12 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f,-1f,0f, 1f,-1f,0f, -1f,1f,0f, 1f,1f,0f)); position(0)
    }
    private val vertexShader = """
        attribute vec4 aPosition;
        uniform mat4 uMVP;
        void main(){ gl_Position = uMVP * aPosition; }
    """.trimIndent()
    private val fragmentShader = """
        precision mediump float;
        uniform vec4 uColor;
        void main(){ gl_FragColor = uColor; }
    """.trimIndent()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        val vs = compile(GLES20.GL_VERTEX_SHADER, vertexShader)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fragmentShader)
        program = GLES20.glCreateProgram().also { GLES20.glAttachShader(it, vs); GLES20.glAttachShader(it, fs); GLES20.glLinkProgram(it) }
        positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        colorHandle = GLES20.glGetUniformLocation(program, "uColor")
        mvpHandle = GLES20.glGetUniformLocation(program, "uMVP")
    }
    private fun compile(type: Int, source: String): Int = GLES20.glCreateShader(type).also {
        GLES20.glShaderSource(it, source); GLES20.glCompileShader(it)
    }
    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) { width = w; height = h; GLES20.glViewport(0, 0, w, h) }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)
        val half = width / 2
        for (eye in 0..1) {
            GLES20.glViewport(eye * half, 0, half, height)
            val eyeOffset = if (eye == 0) -0.032f else 0.032f
            Matrix.setLookAtM(view, 0, eyeOffset, 0f, 0f, eyeOffset, 0f, -1f, 0f, 1f, 0f)
            Matrix.rotateM(view, 0, -headYaw, 0f, 1f, 0f)
            Matrix.rotateM(view, 0, -headPitch, 1f, 0f, 0f)
            Matrix.rotateM(view, 0, -headRoll, 0f, 0f, 1f)
            Matrix.perspectiveM(projection, 0, 72f, half.toFloat() / height.coerceAtLeast(1), 0.05f, 100f)
            drawEnvironment()
            drawPanel(-0.82f, 0.05f, -2.7f, 0.72f, 0.82f, panelColor(0))
            if (panelMode == 1) {
                drawPanel(0f, 0.05f, -2.55f, 0.72f, 0.82f, panelColor(1))
                drawPanel(0.82f, 0.05f, -2.7f, 0.72f, 0.82f, panelColor(2))
            } else {
                drawPanel(0.82f, 0.05f, -2.7f, 0.72f, 0.82f, floatArrayOf(0.12f,0.22f,0.32f,0.78f))
            }
            // Reticle is fixed at the centre of each eye's view.
            drawPanel(0f, 0f, -1.35f, 0.018f, 0.018f, floatArrayOf(0.75f,0.98f,0.94f,0.95f))
        }
        if (selectionPulse > 0f) selectionPulse = (selectionPulse - 0.08f).coerceAtLeast(0f)
    }
    private fun panelColor(index: Int) = when (index) {
        0 -> floatArrayOf(0.20f,0.34f,0.48f,0.86f)
        1 -> floatArrayOf(0.18f,0.42f,0.42f,0.88f)
        else -> floatArrayOf(0.30f,0.30f,0.48f,0.86f)
    }
    private fun drawEnvironment() {
        val c = when (environment) {
            1 -> floatArrayOf(0.10f,0.12f,0.18f,0.18f) // moon
            2 -> floatArrayOf(0.08f,0.22f,0.18f,0.18f) // mountains
            3 -> floatArrayOf(0.18f,0.07f,0.22f,0.18f) // cyber city
            4 -> floatArrayOf(0.04f,0.08f,0.20f,0.18f) // deep space
            else -> floatArrayOf(0.12f,0.18f,0.24f,0.18f)
        }
        drawPanel(0f, 0f, -5f, 5f, 3f, c)
    }
    private fun drawPanel(x: Float, y: Float, z: Float, sx: Float, sy: Float, color: FloatArray) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.scaleM(model, 0, sx, sy, 1f)
        Matrix.multiplyMM(mvp, 0, view, 0, model, 0)
        val finalMvp = FloatArray(16)
        Matrix.multiplyMM(finalMvp, 0, projection, 0, mvp, 0)
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, finalMvp, 0)
        val alpha = if (selectionPulse > 0f) (color[3] + 0.12f).coerceAtMost(1f) else color[3]
        GLES20.glUniform4f(colorHandle, color[0], color[1], color[2], alpha)
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 12, vertexBuffer)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(positionHandle)
    }
}
