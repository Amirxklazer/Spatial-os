package com.amir.spatialos

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent

class SpatialGLView(context: Context) : GLSurfaceView(context) {
    private val spatialRenderer = SpatialRenderer()
    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        setRenderer(spatialRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
        preserveEGLContextOnPause = true
    }
    fun setHeadOrientation(yaw: Float, pitch: Float, roll: Float) { queueEvent { spatialRenderer.setHeadOrientation(yaw, pitch, roll) } }
    fun setEnvironment(index: Int) { queueEvent { spatialRenderer.environment = index } }
    fun setPanelMode(mode: Int) { queueEvent { spatialRenderer.panelMode = mode } }
    fun selectGazedPanel() { queueEvent { spatialRenderer.selectionPulse = 1f } }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) { selectGazedPanel(); performClick() }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
