package com.amir.spatialos

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.opengl.Matrix
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var root: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var rendererView: SpatialGLView
    private lateinit var cameraExecutor: ExecutorService
    private var passthroughEnabled = true
    private var environmentIndex = 0
    private lateinit var sensorManager: SensorManager
    private var rotationSensor: Sensor? = null
    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)
    private val environments = listOf("ROOM", "MOON", "MOUNTAINS", "CYBER CITY", "DEEP SPACE")
    private val cameraRequest = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        cameraExecutor = Executors.newSingleThreadExecutor()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(5, 9, 18)) }

        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))

        rendererView = SpatialGLView(this)
        rendererView.setZOrderOnTop(true)
        rendererView.holder.setFormat(android.graphics.PixelFormat.TRANSLUCENT)
        root.addView(rendererView, FrameLayout.LayoutParams(-1, -1))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            setPadding(12, 12, 12, 22)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xAA101827.toInt())
                cornerRadius = 28f
            }
        }
        val title = TextView(this).apply {
            text = "SPATIAL OS   •   ${environments[environmentIndex]}"
            setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
            setPadding(8, 8, 8, 10)
        }
        controls.addView(title)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        fun addControl(label: String, action: () -> Unit) {
            val b = Button(this).apply {
                text = label; textSize = 10f; isAllCaps = false
                setOnClickListener { action() }
            }
            row.addView(b, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(3, 0, 3, 0) })
        }
        addControl("Environment") {
            environmentIndex = (environmentIndex + 1) % environments.size
            rendererView.setEnvironment(environmentIndex)
            title.text = "SPATIAL OS   •   ${environments[environmentIndex]}"
        }
        addControl("Home") { rendererView.setPanelMode(0) }
        addControl("Apps") { rendererView.setPanelMode(1) }
        addControl("Camera") {
            passthroughEnabled = !passthroughEnabled
            previewView.visibility = if (passthroughEnabled) View.VISIBLE else View.GONE
            if (passthroughEnabled) ensureCamera()
        }
        controls.addView(row)
        val hint = TextView(this).apply {
            text = "Look at a panel • tap or press Cardboard magnet to select"
            setTextColor(0xFFD4E4F5.toInt()); textSize = 10f; gravity = Gravity.CENTER
            setPadding(8, 8, 8, 0)
        }
        controls.addView(hint)
        val params = FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * .76f).toInt(), -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        params.bottomMargin = 8
        root.addView(controls, params)
        setContentView(root)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) ensureCamera()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), cameraRequest)
    }

    private fun ensureCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview)
            } catch (_: Exception) { previewView.visibility = View.GONE }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == cameraRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) ensureCamera()
        else previewView.visibility = View.GONE
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Cardboard magnet triggers vary by headset/phone; common media/enter keys are accepted.
        if (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || keyCode == KeyEvent.KEYCODE_BUTTON_1) {
            rendererView.selectGazedPanel(); return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_GAME_ROTATION_VECTOR || event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            SensorManager.getOrientation(rotationMatrix, orientationAngles)
            if (::rendererView.isInitialized) rendererView.setHeadOrientation(
                Math.toDegrees(orientationAngles[0].toDouble()).toFloat(),
                Math.toDegrees(orientationAngles[1].toDouble()).toFloat(),
                Math.toDegrees(orientationAngles[2].toDouble()).toFloat()
            )
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onResume() {
        super.onResume()
        if (::rendererView.isInitialized) rendererView.onResume()
        rotationSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }
    override fun onPause() {
        sensorManager.unregisterListener(this)
        if (::rendererView.isInitialized) rendererView.onPause()
        super.onPause()
    }
    override fun onDestroy() { if (::cameraExecutor.isInitialized) cameraExecutor.shutdown(); super.onDestroy() }
}
