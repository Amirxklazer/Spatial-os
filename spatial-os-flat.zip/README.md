# Spatial OS — Android Cardboard prototype

A Kotlin + OpenGL ES 2.0 Android prototype for a phone-based spatial interface.

## Included in v0.1.0
- Landscape, immersive Android activity
- Stereoscopic left/right eye rendering with separate viewports
- OpenGL ES floating panel prototype and centre gaze reticle
- Environment cycling: Room, Moon, Mountains, Cyber City, Deep Space
- Home / Apps panel layouts
- CameraX rear-camera passthrough preview behind transparent OpenGL UI (permission required)
- Touch selection and common Cardboard magnet/media key mappings
- GitHub Actions workflow at `.github/workflows/build.yml`

## Build
Open the project in Android Studio (Hedgehog or newer), allow Gradle sync, then run the `app` configuration. Or run:

```bash
gradle assembleDebug
```

The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Important prototype limitations
- This is an early renderer prototype, not a complete visionOS clone. The current environments are color/lighting presets, not finished 360-degree scenes.
- The gyro sensor is not yet wired into the renderer; head orientation tracking is a next implementation step.
- Camera passthrough uses a normal Android preview behind the stereo UI. It is not yet warped/reprojected separately for each eye.
- Hand tracking is not implemented in this build. It needs an on-device hand-landmark model/runtime and performance testing; no hand tracking is claimed to be active.
- Cardboard magnet events differ across devices. Touch and common media/enter key events are supported as a fallback.
- Three.js is not used: this prototype uses native OpenGL ES 2.0 for the stereo renderer.

## Compatibility
Minimum Android API 26 (Android 8.0). Requires OpenGL ES 2.0. Camera passthrough requires a rear camera and camera permission. A gyroscope is recommended for future head tracking. Device performance and camera behavior vary by manufacturer.
